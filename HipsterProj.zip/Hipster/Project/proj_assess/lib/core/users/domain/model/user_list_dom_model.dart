class UserListDomModel {
  String? username;
  String? role;

  UserListDomModel({
    this.username,
    this.role,
  });
}