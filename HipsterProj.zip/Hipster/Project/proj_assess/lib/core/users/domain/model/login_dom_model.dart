class LoginDomModel {
  String? username;
  String? email;
  String? password;

  LoginDomModel({
    this.username,
    this.email,
    this.password
  });
}