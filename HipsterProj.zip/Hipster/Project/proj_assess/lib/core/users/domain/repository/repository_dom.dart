abstract class RepositoryDom {
  userLogin(username, password);
  getUserList();
}