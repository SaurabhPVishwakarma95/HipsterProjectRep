class UserCredentials {
  String get username_credential => "Saurabh";
  String get password_credential => "Example@123";
}