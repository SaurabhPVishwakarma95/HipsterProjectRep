import 'package:flutter/material.dart';
import 'package:proj_assess/core/app/common/constants.dart';
import 'package:proj_assess/core/users/common/user_credentials.dart';
import 'package:proj_assess/main.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});

  final _formKey = GlobalKey<FormState>();
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Constants.loginScreenAppBarTitle),
      ),
      body: Column(
        children: [
          Form(
            key: _formKey,
            child: Container(
              margin: EdgeInsets.all(15.0),
              child: Card(
                child: Column(
                  children: [
                    SizedBox(height: 20),
                    Row(
                      children: [
                        Icon(Icons.verified_user_rounded),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.all(8.0),
                            child: TextFormField(
                              decoration: InputDecoration(
                                filled: true,
                                hintText: "Username"
                              ),
                              controller: username,
                              validator: (value) {
                                if(value!.isEmpty) {
                                  return "Please Enter Username";
                                } else if(value != UserCredentials().username_credential) {
                                  return "Invalid Username";
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Icon(Icons.security_rounded),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.all(8.0),
                            child: TextFormField(
                              decoration: InputDecoration(
                                filled: true,
                                hintText: "Password"
                              ),
                              controller: password,
                              obscureText: Constants.yesFlag,
                              validator: (value) {
                                if(value!.isEmpty) {
                                  return "Please Enter Password";
                                } else if(value != UserCredentials().password_credential) {
                                  return "Invalid Password";
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    GestureDetector(
                      onTap: () {
                        if(_formKey.currentState!.validate()) {
                          Navigator.push(context, MaterialPageRoute(builder: (builder) => MyApp()));                          
                        }                        
                      },
                      child: Container(
                        padding: EdgeInsets.only(top: 10.0, bottom: 10.0, left: 25.0, right: 25.0),
                        color: Colors.lightBlueAccent.shade200,                      
                        child: Text(
                          Constants.loginBtnTitle,
                          style: TextStyle(color: Colors.black)
                        )
                      ),
                    ),                    
                    SizedBox(height: 20)
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}