import 'dart:async';

import 'package:proj_assess/core/users/data/users/use_case/repository_impl.dart';
import 'package:proj_assess/core/users/domain/model/user_list_dom_model.dart';

class UserListRemoteViewModel {
  StreamController<UserListDomModel> userListStreamController = StreamController();
  Stream<UserListDomModel> get userListStream => userListStreamController.stream;

  userListData() async {
    return await RepositoryImpl().fetchUserList();
  }
}