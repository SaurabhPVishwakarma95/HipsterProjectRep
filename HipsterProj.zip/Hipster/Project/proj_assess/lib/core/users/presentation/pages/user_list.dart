import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:proj_assess/core/users/presentation/model/user_list_remote_view_model.dart';

class UserList extends StatefulWidget {
  const UserList({super.key});

  @override
  State<UserList> createState() => _UserListState();
}

class _UserListState extends State<UserList> {

  var userListStream = UserListRemoteViewModel();
  var userListBox, userList;
  
  @override
  void initState() {    
    super.initState();
    initializeDb();
  }

  initializeDb() async {
    userListBox = await Hive.openBox("userListBox");
    userList = userListBox.get("userListDbData") ;    
  }

  getUserList() async* {
    yield await userListStream.userListData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("User List"),        
      ),
      body: StreamBuilder(stream: getUserList(), builder: (context, asyncSnapshot) {
        if(asyncSnapshot.hasError) {
          if(userList != null) {
            if(userList.length > 0) {
              return ListView.builder(
                itemCount: userList.length,
                itemBuilder: (itemBuilder, index) {
                  return ListTile(
                    leading: CircleAvatar(child: Text("${index+1}")),
                    title: Text(userList[index].username.toString()),
                  );
              });           
            } else {
              return Center(child: Text("No Data"));
            }          
          }
        }

        if(asyncSnapshot.hasData) {
          var fetchedData = asyncSnapshot.data as List;
          return ListView.builder(
            itemCount: fetchedData != null ? fetchedData.length : 0,
            itemBuilder: (itemBuilder, index) {
              return ListTile(
                leading: CircleAvatar(child: Text("${index+1}")),
                title: Text(fetchedData[index].username.toString()),
              );
          });         
        }
      return Center(child: Text("Please check your network connection"));
      })
      
    );
  }
}