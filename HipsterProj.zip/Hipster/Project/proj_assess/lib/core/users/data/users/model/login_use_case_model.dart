class LoginUseCaseModel {
  String? username;
  String? email;
  String? password;

  LoginUseCaseModel({
    this.username,
    this.email,
    this.password
  });

  LoginUseCaseModel.fromJson(Map<String, dynamic> json) {
    username = json["username"];
    email = json["email"];
    password = json["password"];
  }

  loginUseCaseModelToJson() {
    Map<String, dynamic> json = new Map<String, dynamic>();
    return {
      json["username"]: username,
      json["email"]: email,
      json["password"]: password
    };
  }
}