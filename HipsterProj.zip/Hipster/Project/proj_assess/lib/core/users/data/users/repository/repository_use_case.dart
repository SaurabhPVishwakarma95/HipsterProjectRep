import 'package:proj_assess/core/users/data/users/use_case/repository_impl.dart';
import 'package:proj_assess/core/users/domain/repository/repository_dom.dart';

class RepositoryUseCase implements RepositoryDom {
  @override
  userLogin(username, password) {
    return RepositoryImpl().checkCredentials(username, password);
  }
  
  @override
  getUserList() {
    return RepositoryImpl().fetchUserList();
  }
}