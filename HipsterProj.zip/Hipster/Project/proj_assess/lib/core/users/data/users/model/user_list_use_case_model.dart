
import 'package:hive/hive.dart';

part 'user_list_use_case_model.g.dart';

@HiveType(typeId: 0)
class UserListUseCaseModel {
  
  @HiveField(0)
  String? username;
  
  @HiveField(1)
  String? role;

  UserListUseCaseModel({
    this.username,
    this.role,
  });

  UserListUseCaseModel.fromJson(Map<String, dynamic> json) {
    username = json["username"];
    role = json["role"];
  }

  userListUseCaseModelToJson() {
    Map<String, dynamic> json = new Map<String, dynamic>();
    return {
      json["username"]: username,
      json["role"]: role
    };
  }

  List<UserListUseCaseModel> userListUseCaseModelToList(List<dynamic> response) {
    List<UserListUseCaseModel> listUserListUseCaseModel = [];
    print("List--->");
    print(response);
    response.forEach((elements) {
      listUserListUseCaseModel.add(UserListUseCaseModel.fromJson(elements));
    });
    return listUserListUseCaseModel;
  }
}