import 'package:dio/dio.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:proj_assess/core/app/fake_json/login_json.dart';
import 'package:proj_assess/core/users/data/users/model/user_list_use_case_model.dart';

class RepositoryImpl {
  checkCredentials(String username, String password) {
    if(username == LoginJson().userJsonCredentials["username"] && password == LoginJson().userJsonCredentials["password"]) {
      return true;
    } else {
      return false;
    }
  }

  fetchUserList() async {
    Hive.registerAdapter(UserListUseCaseModelAdapter());
    var userListBox = await Hive.openBox("userListBox");
    var dio = Dio(BaseOptions(baseUrl: "https://mocki.io/v1/"));
    var request = await dio.get("55e52030-cfbf-4ba1-be4a-10ebd2c9a3b3");
    if(request.statusCode == 200) {
      userListBox.put("userListDbData", (request.data as List).map((json) => UserListUseCaseModel.fromJson(json)).toList());
      return (request.data as List).map((json) => UserListUseCaseModel.fromJson(json)).toList();
    }
  }
}