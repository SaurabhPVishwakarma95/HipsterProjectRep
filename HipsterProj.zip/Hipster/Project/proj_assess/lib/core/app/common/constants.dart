class Constants {
  static String loginScreenAppBarTitle = "Login Screen";
  static bool yesFlag = true;
  static String loginBtnTitle = "Login";
}