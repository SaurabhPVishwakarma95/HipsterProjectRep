import 'package:proj_assess/core/users/common/user_credentials.dart';

class LoginJson {
  var userJsonCredentials = {
    "username": UserCredentials().username_credential,
    "password": UserCredentials().password_credential
  };
}