package com.example.proj_assess

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
